const fs = require("fs");

global.owner = ["6288989923014"];

global.mess = {
    pconly: '_*📌 Perintah Hanya Bisa Diakses Lewat Private Chat Saja*_',
    gconly: '_*📌 Perintah Hanya Bisa Diakses Lewat Group Saja*_',
    ownonly: '_*📌 Perintah Hanya Bisa Diakses Oleh Owner Bot Saja*_',
    ownxadmonly: '_*📌 Perintah Hanya Bisa Diakses Oleh Admin Atau Owner Bot*_',
    errreply:  '_*📌 Terjadi Kesalahan Dalam Memproses Permintaan Anda*_',
    waiting: '_*📌 Tunggu Sebentar Yah Kaka*_',
};

let file = require.resolve(__filename);
fs.watchFile(file, () => {
    fs.unwatchFile(file);
    console.log(`Update ${__filename}`);
    delete require.cache[file];
    require(file);
});